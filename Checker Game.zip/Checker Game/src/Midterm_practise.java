import java.util.Scanner;

public class Midterm_practise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Scanner input=new Scanner(System.in);
		String userinput=input.nextLine();
		int sum=0;
		
		for(int i=0;i<userinput.length();i++) {
			String ch=userinput.charAt(i)+"";
			sum+=Integer.parseInt(ch);
		}
		System.out.print(sum);
		*/
		int[] myarray = new int[10];
		System.out.print(myarray[0]);
	}

}
