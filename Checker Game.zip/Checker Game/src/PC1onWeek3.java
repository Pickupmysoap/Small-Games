import java.util.Scanner;

public class PC1onWeek3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Entre 8 digit credit card number: ");
		String a = input.nextLine();
		int value_one=0;
		int totalvalue_one=0;
		int value_two=0;
		String doublevalue_two="";
		int totaldoublevalue_two=0;

		
		for(int i=a.length()-1; i>=0; i-=2) {
			value_one=Integer.parseInt(a.charAt(i)+"");
			totalvalue_one+=value_one; 
		}
		System.out.println(totalvalue_one);
		for(int i=a.length()-2;i>=0;i-=2) {
			value_two=(Integer.parseInt(a.charAt(i)+""))*2;
			doublevalue_two+=value_two;
		}
		System.out.println(doublevalue_two);
		
		for(int i=0; i<doublevalue_two.length();i++) {
			totaldoublevalue_two+=Integer.parseInt(doublevalue_two.charAt(i)+"");
		}

		int finalvalue_check=totalvalue_one+totaldoublevalue_two;
		if((finalvalue_check%10)==0) {
			System.out.println("This is a valid credit card.");
		}
		else {
			System.out.println("This credit card is not valid.");
		}
		input.close();
	}

}
