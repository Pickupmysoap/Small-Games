


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WritingtoFile {

	public static void main(String[] args) {
		String filename1 = "data1.txt";
		String filename2 = "data2.txt";
		File f1 = new File(filename1);
		File f2 = new File(filename2);
		
		try {
			Date objDate = new Date();
			System.out.println("The default date format: " + objDate.toString());
			
			String result = formatTheDate(objDate,"MMMM d, y");
			System.out.println("using MMMM d, y format: " + result );
			
			String result2 = formatTheDate(objDate,"hh:mm:ss");
			System.out.println("using hh:mm:ss: " + result2 );
			
			String msg = String.format("%10s | %-10s", result,result2);
			PrintWriter pw = new PrintWriter(f1);
			pw.println(msg);
			pw.close();
			
			
			FileWriter fw = new FileWriter(f2,true);
			fw.write(msg + "\n");	
			fw.close();

		} catch (Exception e) {
			
			System.out.println(e.getMessage());
		}

	}
	
	private static String formatTheDate(Date theDate, String strDateFormat) {
		String result;
		
		SimpleDateFormat objSDF = new SimpleDateFormat(strDateFormat); 
		result = objSDF.format(theDate); 
		return result;
	}
	
	/* 
	 * Date format
		y	Year												2018
		M	Month in year										July or Jul or 07
		w	Week in year										27
		W	Week in month										2
		D	Day in year											189
		d	Day in month										10
		F	Day of week in month								2
		E	Day name in week									Tuesday or Tue
		u	Day number of week (1 = Monday, ..., 7 = Sunday)	1
		a	Am/pm marker										PM
		H	Hour in day (0-23)									0
		k	Hour in day (1-24)									24
		K	Hour in am/pm (0-11)								0
		h	Hour in am/pm (1-12)								12
		m	Minute in hour										30
		s	Second in minute									55
		
		 */
	

}
