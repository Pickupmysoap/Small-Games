import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFileChooser;


public class ReadFile {

	public static void main(String[] args) {
		String []array= {"12","35","5646"};
		ArrayList<String>movie=new ArrayList<String>();
		movie.add(array);
		
////		String currentDirectory = System.getProperty("Movie_Data.csv");
////		JFileChooser fc = new JFileChooser(currentDirectory);
//		
//		int returnVal = fc.showOpenDialog(null);
//		
//		if (returnVal == JFileChooser.APPROVE_OPTION) {
//            File file = fc.getSelectedFile();
//            System.out.println("Filename with complete path: " + fc.getSelectedFile());
//          
//            FileReader fr = null;
//            try {
//				fr = new FileReader(file); // reads per character
//				BufferedReader br = new BufferedReader(fr); // can read Strings
//				
//				String[] data = new String[21];
//				
//				data[0] = br.readLine();
//				data[1] = br.readLine();
//				
//				System.out.println(data[1]);
//				
//				while ((br.readLine()) != null) {
//					System.out.println(data);
//				}
//				
//				
//				
//			} catch (Exception e) {
//				System.out.println(e.getMessage());
//			} finally {
//				if (fr != null)
//					try {
//						fr.close();
//					} catch (IOException e) {
//						System.out.println(e.getMessage());
//					}
//			}
//            
//		}
//
	}

}
