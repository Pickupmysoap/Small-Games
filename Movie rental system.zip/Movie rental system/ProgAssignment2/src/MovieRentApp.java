import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;


public class MovieRentApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		String userinput;
		String [][]allmovies=new String[20][3];
		FileReader fr=null;
		String filename="Movie_Data.csv";
		String line= null;
		Date rentdate=new Date();
		initializedata(filename,allmovies);//use a 2D array to store all the movies from the file;
		ArrayList <String> earnings=new ArrayList<String>();
		
		do {
			System.out.println("1. Developer");
			System.out.println("2. Search.");
			System.out.printf("%5s","       a. All avilable movies");
			System.out.println();
			System.out.printf("%5s","       b. By genre.");
			System.out.println();
			System.out.printf("%5s","       c. By title.");
			System.out.println();
			System.out.println("3. Rent.");
			System.out.println("4. Return.");
			System.out.println("5. Earnings.");
			System.out.println("6. Exit.");
			userinput=input.next();
			String option=userinput.toLowerCase();
			
			switch(option) {
				case "1": nameofdev();
					break;
				case "2a": searchallmovies(allmovies);
					break;
				case "2b":search_genre(allmovies,input);
					break;
				case "2c":search_title(allmovies,input);
					break;
				case "3": rent(input,allmovies,rentdate,earnings);
					break;
				case "4": return_movie(allmovies,filename,rentdate);
					break;
				case "5": display_earnings(earnings,filename,allmovies);
					break;
				case "6":System.exit(0);
				
				default: System.out.println("Wrong input, please input again!");
					
			}
		}while(userinput!="6");
	}

	public static void nameofdev() {
		System.out.println();
		System.out.println();
		System.out.println("Developer: Wenjie Liang. Student #: 100226553");
		System.out.println();
		System.out.println();
	}
	//store all the movies from the file to a 2D array
	public static void initializedata(String filename,String [][]allmovies) {
		File f=new File(filename);
		try {
			Scanner data=new Scanner(f);
			String []s;
			int index=0;
			data.nextLine();
			String d;
			while(data.hasNextLine()) {
				d=data.nextLine();
				s=d.split("\"");
				if(s.length!=3)    //has no " "
					s=d.split(",");
				else
					s=d.split("\",|,\"");
					
				
				allmovies[index][0]=s[0];
				allmovies[index][1]=s[1];
				allmovies[index][2]=s[2];				
				index++;
			}
			
		}catch(Exception e) {
			System.out.print(e.getMessage());
		}	
	}
	//print out all the movies available
	public static void searchallmovies(String [][]allmovies) {
		System.out.printf("%20s %-35s %-15s %34s"," ","<<--------------------------------","Movie Available","-------------------------------->>");
		System.out.println();
		System.out.println();
		for(int i=0;i<20;i++) {
			System.out.printf("%20s %-33s"," ",allmovies[i][0]);
			System.out.printf("%-43s",allmovies[i][1]);
			System.out.printf("%10s",allmovies[i][2]);
			System.out.println();
		}
		System.out.println();
		System.out.println();
	}
	//look for all the movies with same genre which entered by the user, then print out
	public static void search_genre(String [][]allmovies,Scanner input) {
		System.out.print("Please enter the genre you like to search: ");
		String input_gen=input.next();
		System.out.println();
		String genre=input_gen.toLowerCase();
		System.out.printf("%20s %-35s %-15s %34s"," ","<<--------------------------------","Movie Available","-------------------------------->>");
		System.out.println();
		System.out.println();
		for(int i=0;i<allmovies.length;i++) {
			int counter=0;
			for(int j=0;j<allmovies[i][0].length();j++) {
				if(genre.charAt(counter)==(allmovies[i][0].toLowerCase()).charAt(j)) {
						counter++;
				}
				if(counter==genre.length()) {
					j=allmovies[i][0].length();
					counter=0;
					System.out.printf("%-20s %-33s","",allmovies[i][0]);
					System.out.printf("%-43s",allmovies[i][1]);
					System.out.printf("%10s",allmovies[i][2]);
					System.out.println();
				}
			}
		}
		System.out.println();
		System.out.println();
	}
		
	//look for all the movies with the same title which entered by the user, then print out
	public static void search_title(String [][]allmovies,Scanner input) {
		System.out.print("Please enter the title you like to search: ");
		String titleinput=input.next();
		String title=titleinput.toLowerCase();
		System.out.println();
		System.out.printf("%20s %-35s %-15s %34s"," ","<<--------------------------------","Movie Available","-------------------------------->>");
		System.out.println();
		System.out.println();
		
		for(int i=0;i<allmovies.length;i++) {
			int counter=0;
			for(int j=0;j<allmovies[i][1].length();j++) {
				if(title.charAt(counter)==(allmovies[i][1].toLowerCase()).charAt(j)) {
						counter++;
				}
				if(counter==title.length()) {
					counter=0;
					j=allmovies[i][1].length();
					System.out.printf("%-20s %-33s"," ", allmovies[i][0]);
					System.out.printf("%-43s",allmovies[i][1]);
					System.out.printf("%10s",allmovies[i][2]);
					System.out.println();
				}
			}
		}
		System.out.println();
		System.out.println();
	}
	//"rent" function, find the movie wanted, check availability, sum the fee, print out the receipt and record to a file
	public static void rent(Scanner input,String [][]allmovies,Date rentdate,ArrayList earnings) {
		String msg="";
		DecimalFormat df2=new DecimalFormat(".00");
		Scanner input2=new Scanner(System.in);
		double totalfee=0;
		String rent="";
		String filename="Renting Record.txt";
		File f1=new File(filename);
		ArrayList <Integer>wantmovie=new ArrayList<Integer>();
		String temp="";
		System.out.print("Please enter your name: ");
		String name=input.next();
		msg+="Customer: "+name+"\n";
		//rent multiple movies, when the user entered "0", end renting and print out receipt
		while(!rent.equalsIgnoreCase("0")) {
			System.out.println("Enter the movie you like. Enter 0 to finish: ");
			rent=input2.nextLine();
			int counter=0;
			
			for(int i=1;i<=allmovies.length;i++) {
				if(!temp.equals(rent)) {
					if(rent.equalsIgnoreCase(allmovies[i-1][1])) {
						wantmovie.add(i);
//add all the movies that are rented out by different customers. need this one to calculate earnings later. same movie can be rented more than one time
						earnings.add(rent);
					}
					else
						counter++;
				}
			}
			if(counter==allmovies.length && !rent.equals("0"))
				System.out.println("This movie is not avaliable. Please enter again.");
			temp=rent;
		}
		System.out.println();
		System.out.println();
		System.out.println("Customer: "+name);
		System.out.println(rentdate.toString());
		msg+=rentdate.toString()+"\n";
		System.out.println();
		System.out.printf("%25s %-27s %8s %-27s", " ","<<------------------------", "Receipt", "--------------------->>");
		System.out.println();
		System.out.println();
		System.out.printf("%28s %-45s %-10s","" ,"Movie Tile","rent fee");
		System.out.println();
		
		for(int i=0;i<wantmovie.size();i++) {
			System.out.printf("%28s %-43s %10s", " ",allmovies[wantmovie.get(i)-1][1],allmovies[wantmovie.get(i)-1][2]);
			msg+=allmovies[wantmovie.get(i)-1][1]+"  "+allmovies[wantmovie.get(i)-1][2]+"\n";
			System.out.println();
			totalfee += Double.parseDouble((allmovies[wantmovie.get(i)-1][2].substring(1)));
//once the movie is rented, it is not available any more. remove it from the movies list
			remove_rented(allmovies,wantmovie.get(i)-1);
		}
		msg+="$"+totalfee;
		System.out.println();
		System.out.printf("%72s %10s"," ","$"+df2.format(totalfee));
		System.out.println();
		System.out.println();
		System.out.println();
		try {
			FileWriter fw=new FileWriter(f1,true);
			fw.write(msg+"\n");
			fw.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public static void remove_rented(String [][]allmovies,int i) {
		String []emp={" "," "," "};
		allmovies[i]=emp;
	}
	//"return function" check validity,check if the movie belongs to the original list, check if this movie is rented out so that customer can return it.
	public static void return_movie(String[][]allmovies,String filename,Date rentdate) {
		String msg="";
		Scanner input=new Scanner(System.in);
		System.out.println("Please enter your name: ");
		String name=input.nextLine();
		msg+="Customer: "+name+"\n";
		msg+=rentdate.toString()+"\n";
		String return_mov="";
		String filename2="Returning Record.txt";
		File f2=new File(filename2);
		
		
		while(!return_mov.equalsIgnoreCase("0")) {
			System.out.println("Which movie you like to return, enter 0 to finish: ");
			return_mov=input.nextLine();
			
			if(check_duplicate(return_mov,allmovies)) {
				System.out.println("This movie is not rented. You cannot return it. Please enter another one.");
			}
			
			else {
				File f=new File(filename);
				try {
					Scanner data=new Scanner(f);
					String []s;
					int index=0;
					data.nextLine();
					String d;
					int check_exist=0;
					while(data.hasNextLine()) {
						d=data.nextLine();
						s=d.split("\"");
						if(s.length!=3)    //has no " "
							s=d.split(",");
						else
							s=d.split("\",|,\"");
						
						if(allmovies[index][1]==" " && s[1].equalsIgnoreCase(return_mov)) {
							allmovies[index][0]=s[0];
							allmovies[index][1]=s[1];
							allmovies[index][2]=s[2];
							System.out.println("Thank you, you already return the movie.");
							msg+=allmovies[index][1];
						}
						if(!return_mov.equalsIgnoreCase(s[1]))
							check_exist++;
						index++;
						}
					if(check_exist==allmovies.length && !return_mov.equals("0"))
						System.out.println("This movie does not exist at all.");
					}catch(Exception e) {
						System.out.print(e.getMessage());
				}
			}
		}
		try {
			FileWriter fw=new FileWriter(f2,true);
			fw.write(msg+"\n");
			fw.close();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public static boolean check_duplicate(String return_mov,String [][]allmovies) {
		for(int i=0;i<allmovies.length;i++) {
			if(return_mov.equalsIgnoreCase(allmovies[i][1]))
				return true;
		}
		return false;
	}
	
	//"display earnings" function. use binary search, sort the arraylist(earnings) first, than find out how many times a movie was rented.
	public static void display_earnings(ArrayList earnings,String filename, String [][]allmovies) {
		System.out.println();
		System.out.println();
		DecimalFormat df2=new DecimalFormat(".00");
		initializedata(filename,allmovies);
		ArrayList <Integer>times=new ArrayList<Integer>();
		System.out.printf("%-45s %6s %20s %15s","Movie Title","Rent Fee","# of times borrowed","Earnings");
		System.out.println();
		Collections.sort(earnings);
		double unit_price=0;
		double totalprice=0;
		double sum=0;
		int counter=1;
		int counter2=0;
		
		if(earnings.size()>1) {
			for(int i=1;i<earnings.size();i++) {
				if(i==earnings.size()-1 && !earnings.get(i).equals(earnings.get(i-1))) {
					times.add(1);
					times.add(1);
				}
				else {
					if(earnings.get(i).equals(earnings.get(i-1))) {
						if(i==earnings.size()-1)
							times.add(counter+1);
						else
							counter++;
					}
					else if(i==earnings.size()-1)
						times.add(1);
					
					else {
						times.add(counter);
						counter=1;
					}
				}
			}
		}
		else
			times.add(1);
		
		if(earnings.size()>0) {
			for(int i=0;i<earnings.size();) {
				String s1=(String) earnings.get(i);
				for(int j=0;j<allmovies.length;j++) {
					if(s1.equalsIgnoreCase(allmovies[j][1])) {
						unit_price=Double.parseDouble(allmovies[j][2].substring(1));
						totalprice=((double)times.get(counter2))*unit_price;
						System.out.printf("%-45s $%-6.2f %20d  %15s",allmovies[j][1],unit_price,(int)times.get(counter2),"$"+df2.format(totalprice));
						System.out.println();
						sum+=totalprice;
					}
				}
				i+=times.get(counter2);
				counter2++;
			}
			System.out.println();
			System.out.printf("%-45s %6s %20s %15s", " "," ","Total", "$"+df2.format(sum));
			System.out.println();
			System.out.println();
		}
	}

}
