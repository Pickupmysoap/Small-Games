import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Scanner;

public class Trying {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String>myarray=new ArrayList<String>();
		myarray.add("a");
		myarray.add("f");
		myarray.add("z");
		myarray.add("c");
		Collections.sort(myarray);
		String s1=myarray.get(0);
		
		for(int i=0;i<myarray.size();i++) {
			System.out.print(myarray.get(i));
		}
	}

}